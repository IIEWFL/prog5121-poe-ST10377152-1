package prog5121part1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

public class TaskTest {

    private Task task1;
    private Task task2;
    private Task task3;
    private Task task4;
    private Task task5;

    private List<String> developers;
    private List<String> taskNames;
    private List<String> taskIDs;
    private List<Integer> taskDurations;
    private List<String> taskStatuses;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        developers = new ArrayList<>();
        taskNames = new ArrayList<>();
        taskIDs = new ArrayList<>();
        taskDurations = new ArrayList<>();
        taskStatuses = new ArrayList<>();

        task1 = new Task();
        task1.setTaskName("Create Login");
        task1.setTaskDescription("Create Login to authenticate users");
        task1.setDeveloperDetails("Mike Smith");
        task1.setTaskDuration(5);
        task1.setTaskID(task1.createTaskID());
        task1.setTaskStatus("To Do");

        task2 = new Task();
        task2.setTaskName("Create Add Features");
        task2.setTaskDescription("Create Add Task feature to add task users");
        task2.setDeveloperDetails("Edward Harrison");
        task2.setTaskDuration(8);
        task2.setTaskID(task2.createTaskID());
        task2.setTaskStatus("Doing");

        task3 = new Task();
        task3.setTaskName("Create Reports");
        task3.setTaskDescription("Create report for management");
        task3.setDeveloperDetails("Samantha Paulson");
        task3.setTaskDuration(2);
        task3.setTaskID(task3.createTaskID());
        task3.setTaskStatus("Done");

        task4 = new Task();
        task4.setTaskName("Add Arrays");
        task4.setTaskDescription("Add Arrays feature to application");
        task4.setDeveloperDetails("Glenda Oberholzer");
        task4.setTaskDuration(11);
        task4.setTaskID(task4.createTaskID());
        task4.setTaskStatus("To Do");

        developers.add(task1.getDeveloperDetails());
        developers.add(task2.getDeveloperDetails());
        developers.add(task3.getDeveloperDetails());
        developers.add(task4.getDeveloperDetails());

        taskNames.add(task1.getTaskName());
        taskNames.add(task2.getTaskName());
        taskNames.add(task3.getTaskName());
        taskNames.add(task4.getTaskName());

        taskIDs.add(task1.getTaskID());
        taskIDs.add(task2.getTaskID());
        taskIDs.add(task3.getTaskID());
        taskIDs.add(task4.getTaskID());

        taskDurations.add(task1.getTaskDuration());
        taskDurations.add(task2.getTaskDuration());
        taskDurations.add(task3.getTaskDuration());
        taskDurations.add(task4.getTaskDuration());

        taskStatuses.add(task1.getTaskStatus());
        taskStatuses.add(task2.getTaskStatus());
        taskStatuses.add(task3.getTaskStatus());
        taskStatuses.add(task4.getTaskStatus());
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testTaskDescriptionLength() {
        assertTrue(task1.checkTaskDescription());
        assertTrue(task2.checkTaskDescription());
        assertTrue(task3.checkTaskDescription());
        assertTrue(task4.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        assertEquals("CR:0:ITH", task1.createTaskID());
        assertEquals("CR:1:SON", task2.createTaskID());
        assertEquals("CR:2:SON", task3.createTaskID());
        assertEquals("CR:3:ZER", task4.createTaskID());
    }

    @Test
    public void testReturnTotalHours() {
        int expectedTotalHours = 26;
        assertEquals(expectedTotalHours, task1.returnTotalHours() + task2.returnTotalHours() + task3.returnTotalHours() + task4.returnTotalHours());
    }

    @Test
    public void testAddMultipleTasks() {
        Task task5 = new Task();
        task5.setTaskName("Create Summary");
        task5.setTaskDescription("Summarize all tasks and report");
        task5.setDeveloperDetails("Natalie Curtis");
        task5.setTaskDuration(3);
        task5.setTaskID(task5.createTaskID());
        task5.setTaskStatus("To Do");

        assertEquals("Summarize all tasks and report", task5.getTaskDescription());
        assertEquals("Create Summary", task5.getTaskName());
        assertEquals("Natalie Curtis", task5.getDeveloperDetails());
        assertEquals(3, task5.getTaskDuration());
        assertEquals("CR:4:TIS", task5.getTaskID());
        assertEquals("To Do", task5.getTaskStatus());
    }

    @Test
    public void testStoreMultipleTasks() {
        assertEquals(4, developers.size());
        assertEquals(4, taskNames.size());
        assertEquals(4, taskIDs.size());
        assertEquals(4, taskDurations.size());
        assertEquals(4, taskStatuses.size());
    }
}
