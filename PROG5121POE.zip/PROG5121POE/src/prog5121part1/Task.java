/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121part1;

/**
 *
 * @author lab_services_student
 */
public class Task {

    private String taskName;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
    private static int taskNumber = 0;

public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

 public boolean checkTaskDescription() {
        return taskDescription != null && taskDescription.length() <= 50;
    }

   public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String createTaskID() {
        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" +
                developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        taskNumber++;
        return taskID;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\nDeveloper Details: " + developerDetails +
                "\nTask Number: " + taskNumber + "\nTask Name: " + taskName + "\nTask Description: " +
                taskDescription + "\nTask ID: " + taskID + "\nDuration: " + taskDuration + " hours";
    }

    public int returnTotalHours() {
        return taskDuration;
    }

    public static int getTaskNumber() {
        return taskNumber;
    }
    
    public int getTaskDuration() {
        return taskDuration;
    }

public String getTaskName() {
    return taskName;
}

public String getTaskDescription() {
    return taskDescription;
}

public String getDeveloperDetails() {
    return developerDetails;
}

public String getTaskID() {
    return taskID;
}

public String getTaskStatus() {
    return taskStatus;
}

}