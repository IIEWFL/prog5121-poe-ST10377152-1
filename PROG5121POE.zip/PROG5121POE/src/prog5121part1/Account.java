package prog5121part1;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Account {

    //references
//https://stackoverflow.com/questions/35972011/how-to-call-an-arraylist
//https://www.dummies.com/article/technology/programming-web-design/java/use-array-lists-in-java-172154/
//https://www.w3schools.com/java/java_arraylist.asp
    
    private static List<String> developers = new ArrayList<>();
    private static List<String> taskNames = new ArrayList<>();
    private static List<String> taskIDs = new ArrayList<>();
    private static List<Integer> taskDurations = new ArrayList<>();
    private static List<String> taskStatuses = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("Enter username:");
        String username = scanner.nextLine();
        while (!Login.checkUserName(username)) {
            System.out.print(Login.registerUser(username, username, username, username));
            System.out.println("Enter username:");
            username = scanner.nextLine();
        }
        System.out.println("Enter password:");
        String password = scanner.nextLine();
        while (!Login.checkPasswordComplexity(password)) {
            System.out.println(Login.registerUser(username, password, username, username));
            System.out.println("Enter password:");
            password = scanner.nextLine();
        }
        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();

        String registrationMessage = login.registerUser(username, password, firstName, lastName);
        System.out.println(registrationMessage);

        System.out.println("Enter username for login:");
        String loginUsername = scanner.nextLine();

        System.out.println("Enter password for login:");
        String loginPassword = scanner.nextLine();

        boolean loginStatus = login.loginUser(loginUsername, loginPassword, username, password);

        String loginStatusMessage = login.returnLoginStatus(loginStatus, firstName, lastName);
        System.out.println(loginStatusMessage);

        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        scanner.close();

        int choice;
        do {
            String input = JOptionPane.showInputDialog(null, "Choose an option:\n1. Add tasks\n2. Show report\n3. Quit");
            choice = Integer.parseInt(input);

            switch (choice) {
                case 1:
                    addTasks();
                    break;
                case 2:
                    showReport();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Quitting the application.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice, please choose again.");
            }
        } while (choice != 3);
    }

    private static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter number of tasks:"));

        Task[] tasks = new Task[numTasks];

        for (int i = 0; i < numTasks; i++) {
            Task task = new Task();
            task.setTaskName(JOptionPane.showInputDialog(null, "Enter task name:"));
            while (!task.checkTaskDescription()) {
                JOptionPane.showMessageDialog(null, "Task description should not be more than 50 characters.");
                task.setTaskDescription(JOptionPane.showInputDialog(null, "Enter task description:"));
            }
            task.setDeveloperDetails(JOptionPane.showInputDialog(null, "Enter developer details:"));
            task.setTaskDuration(Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration in hours:")));
            task.setTaskID(task.createTaskID());
            task.setTaskStatus(JOptionPane.showInputDialog(null, "Enter task status (To Do, Done, Doing):"));

            tasks[i] = task;

            developers.add(task.getDeveloperDetails());
            taskNames.add(task.getTaskName());
            taskIDs.add(task.getTaskID());
            taskDurations.add(task.getTaskDuration());
            taskStatuses.add(task.getTaskStatus());

            JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

        int totalHours = calculateTotalHours(tasks);
        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours);
    }

    private static int calculateTotalHours(Task[] tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.getTaskDuration();
        }
        return totalHours;
    }

    private static void showReport() {
        int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Choose a report type:\n1. Display all tasks with status 'Done'\n2. Display task with the longest duration\n3. Search for a task by name\n4. Display developer and task names"));

        switch (choice) {
            case 1:
                displayTasksWithStatusDone();
                break;
            case 2:
                displayTaskWithLongestDuration();
                break;
            case 3:
                searchTaskByName();
                break;
            case 4:
                displayDeveloperAndTaskNames();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid choice, please choose again.");
        }
    }

    //https://www.geeksforgeeks.org/arraylist-in-java/
    
    private static void displayTasksWithStatusDone() {
        StringBuilder report = new StringBuilder("Tasks with status 'Done':\n");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if ("Done".equalsIgnoreCase(taskStatuses.get(i))) {
                report.append("Task ID: ").append(taskIDs.get(i)).append("\n");
                report.append("Task Name: ").append(taskNames.get(i)).append("\n");
                report.append("Developer: ").append(developers.get(i)).append("\n");
                report.append("Duration: ").append(taskDurations.get(i)).append(" hours\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void displayTaskWithLongestDuration() {
        if (taskDurations.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return;
        }

        int maxDuration = 0;
        int maxIndex = 0;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }

        StringBuilder report = new StringBuilder("Task with the longest duration:\n");
        report.append("Task ID: ").append(taskIDs.get(maxIndex)).append("\n");
        report.append("Task Name: ").append(taskNames.get(maxIndex)).append("\n");
        report.append("Developer: ").append(developers.get(maxIndex)).append("\n");
        report.append("Duration: ").append(taskDurations.get(maxIndex)).append(" hours\n\n");

        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void searchTaskByName() {
        String searchName = JOptionPane.showInputDialog(null, "Enter the task name to search:");
        StringBuilder report = new StringBuilder("Search results:\n");
        boolean found = false;

        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equalsIgnoreCase(searchName)) {
                report.append("Task ID: ").append(taskIDs.get(i)).append("\n");
                report.append("Task Name: ").append(taskNames.get(i)).append("\n");
                report.append("Developer: ").append(developers.get(i)).append("\n");
                report.append("Duration: ").append(taskDurations.get(i)).append(" hours\n");
                report.append("Status: ").append(taskStatuses.get(i)).append("\n\n");
                found = true;
            }
        }

        if (!found) {
            report.append("No tasks found with the name '").append(searchName).append("'.");
        }

        JOptionPane.showMessageDialog(null, report.toString());
    }

    private static void displayDeveloperAndTaskNames() {
        StringBuilder report = new StringBuilder("Developer and Task Names:\n");
        for (int i = 0; i < developers.size(); i++) {
            report.append("Developer: ").append(developers.get(i)).append("\n");
            report.append("Task Name: ").append(taskNames.get(i)).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }
}

